import json, time, urllib.request
from datetime import datetime, timezone

ASSETS = {
    "SPY":"SPY","QQQ":"QQQ","IWM":"IWM","VOO":"VOO","AAPL":"AAPL","MSFT":"MSFT","NVDA":"NVDA","AMZN":"AMZN","META":"META","F":"F","CMI":"CMI","GM":"GM"
}
CRYPTO = {"BTC":"bitcoin","ETH":"ethereum"}


def get_json(url):
    req=urllib.request.Request(url, headers={"User-Agent":"TradeLab/9.0 market-data updater"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)

def yahoo(symbol, interval, range_):
    return get_json(f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?interval={interval}&range={range_}")

def parse_yahoo(j):
    r=j["chart"]["result"][0]
    q=r["indicators"]["quote"][0]
    prices=[]; timestamps=[]
    for ts,c in zip(r.get("timestamp",[]), q.get("close",[])):
        if c is not None:
            prices.append(float(c)); timestamps.append(int(ts))
    return prices,timestamps

def main():
    out={"updatedAt":datetime.now(timezone.utc).isoformat(),"source":"Yahoo Finance via scheduled GitHub Action; CoinGecko for crypto","assets":{}}
    for label,symbol in ASSETS.items():
        try:
            daily,ts=parse_yahoo(yahoo(symbol,"1d","400d"))
            live=[]
            try: live,live_ts=parse_yahoo(yahoo(symbol,"1m","1d"))
            except Exception: live=[]; live_ts=[]
            price=live[-1] if live else daily[-1]
            stamp=live_ts[-1] if live else ts[-1]
            out["assets"][label]={"prices":daily,"timestamps":ts,"price":price,"timestamp":stamp,"mode":"1m" if live else "daily"}
        except Exception as e:
            out["assets"][label]={"error":str(e),"prices":[]}
    for label,cid in CRYPTO.items():
        try:
            j=get_json(f"https://api.coingecko.com/api/v3/coins/{cid}/market_chart?vs_currency=usd&days=400&interval=daily")
            pts=[x for x in j.get("prices",[]) if isinstance(x,list) and len(x)>=2 and x[1] is not None]
            prices=[float(x[1]) for x in pts]; ts=[int(x[0]/1000) for x in pts]
            out["assets"][label]={"prices":prices,"timestamps":ts,"price":prices[-1],"timestamp":ts[-1],"mode":"daily"}
        except Exception as e:
            out["assets"][label]={"error":str(e),"prices":[]}
    with open("market-data.json","w") as f: json.dump(out,f,separators=(",",":"))

if __name__=="__main__": main()
